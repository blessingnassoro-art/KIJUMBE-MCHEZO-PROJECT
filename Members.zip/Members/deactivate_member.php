<?php

require_once "../includes/db.php";
require_once "../includes/auth.php";

requireRole(["admin", "coordinator"]);

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);

    echo json_encode([
        "success" => false,
        "message" => "Invalid request method."
    ]);

    exit;
}

$id = (int) ($_POST["id"] ?? 0);

if ($id <= 0) {

    echo json_encode([
        "success" => false,
        "message" => "Invalid member ID."
    ]);

    exit;
}

$check = $pdo->prepare(
    "SELECT id FROM members WHERE id = ? LIMIT 1"
);

$check->execute([$id]);

if (!$check->fetch()) {

    echo json_encode([
        "success" => false,
        "message" => "Member not found."
    ]);

    exit;
}

$sql = "UPDATE members
        SET status = 'inactive'
        WHERE id = ?";

$stmt = $pdo->prepare($sql);

$stmt->execute([$id]);

echo json_encode([
    "success" => true,
    "message" => "Member deactivated successfully."
]);